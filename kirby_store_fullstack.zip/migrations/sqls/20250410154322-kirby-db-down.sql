/* Replace with your SQL commands */
DROP TABLE Order_Products;
DROP TABLE Orders;
DROP TABLE Users;
DROP TABLE Products;
